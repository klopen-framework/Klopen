"""Hybrid PDF extraction engine.

Combines PyMuPDF for layout-aware structural extraction with spaCy
for sentence segmentation (applied downstream by the caller):

    PyMuPDF (fitz)     — block/line/span layout + font metadata
    spaCy              — sentence segmentation (downstream)

Why this matters
----------------
A naive single-tool full-page text extract followed by sentence
segmentation fails in three systematic ways:

  1. Titles glued to body. Section headings without terminal
     punctuation get concatenated with the following paragraph into
     a single "sentence", polluting the corpus.

  2. Multi-column paragraph loss. Sentences spanning a column
     boundary are either reconstructed wrongly or dropped entirely.

  3. Word-joining hyphenation artefacts produced when end-of-line
     hyphenation removal goes wrong, or when whitespace is silently
     dropped at line breaks during extraction.

The hybrid approach addresses each:
  - PyMuPDF's `get_text("dict")` returns blocks with font metadata
    (size, weight, flags). A font-size histogram across the page
    separates headings (outliers on the large side) from body text.
  - PyMuPDF's block bounding boxes give column structure for free —
    no heuristic x-histogram needed. Blocks in different columns
    have disjoint bbox x-ranges.
  - Hyphenation and concatenation repair: regex-based reconstruction
    of words split across line or column breaks, plus splitting of
    tokens incorrectly joined when whitespace was lost (see
    `_repair_concatenated_words`).

Reference: Bast & Korzen (2017), "A benchmark and evaluation for text
extraction from PDF", ACM/IEEE JCDL, which established that reading-
order reconstruction in research-grade PDF extraction benefits most
from combining layout detection with character-accurate text recovery.
"""
from __future__ import annotations
from klopen.extract.text_utils import repair_pdf_text

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

try:
    import fitz  # PyMuPDF
    FITZ_AVAILABLE = True
except ImportError:
    FITZ_AVAILABLE = False
    logger.warning("PyMuPDF (fitz) not installed; hybrid extraction disabled")


# ---------------------------------------------------------------------------
# Tuning constants
# ---------------------------------------------------------------------------

# Font size above which a block is treated as a heading rather than body.
# Expressed as a ratio relative to the page-level median body font size.
# A ratio of 1.35 means "any block whose font is at least 35% larger than
# the median body font is a heading".
HEADING_FONT_SIZE_RATIO = 1.35

# Bold weight flag in PyMuPDF span["flags"]. 16 = bold, 2 = italic, 1 = superscript.
# Headings are typically bold even when their font size matches body text
# (inline bold lead-ins at the start of a paragraph).
FONT_FLAG_BOLD = 16

# Minimum character count for a block to be considered a sentence-bearing
# paragraph. Short blocks (< 40 chars) are almost always captions, labels,
# page numbers, or decorative text that contain no codable intent.
MIN_BODY_CHARS = 40

# Maximum character count for a block to be considered a "heading" even
# if its font size is only slightly above body. Real headings are short
# ("Strategies and goals"); a large-font paragraph is still body text.
MAX_HEADING_CHARS = 120

# Vertical gap threshold (as a multiple of line height) above which two
# adjacent blocks are treated as separate paragraphs. 1.5 handles
# normal paragraph spacing; lower values cause merging.
PARAGRAPH_GAP_MULTIPLE = 1.5


# ---------------------------------------------------------------------------
# Hyphenation and concatenation repair
# ---------------------------------------------------------------------------
# End-of-line hyphenation: "state-\nment" → "statement"
_HYPHEN_NEWLINE_RE = re.compile(r"([a-z])-\s*\n\s*([a-z])")

# Column-gap hyphenation: "state-   ment" (3+ spaces) → "statement"
_HYPHEN_MULTISPACE_RE = re.compile(r"([a-z])-\s{3,}([a-z])")

# Known-safe deny list: words where a conjunction appears word-internally
# but is NOT a concatenation artefact. These are reverted after initial
# splitting. Case-insensitive match.
_CONCAT_SAFELIST = {
    "andorra", "theorem", "theater", "theater", "theatre", "toward", "towards",
    "token", "into", "onto", "upon", "within", "without", "within",
    "inception", "inherent", "inheritance", "initial", "initiate", "initiative",
    "income", "increase", "index", "incident", "incidence",
    "atomic", "atom", "attack", "attract", "attain", "attire", "attend",
    "fortune", "formal", "format", "former", "forward", "forest",
    "between", "beyond", "behind", "behold",
    "organization", "organic", "organism", "organ",
    "fromage",
    "bylaw", "byline", "bypass", "byword", "byproduct",
}

# Specific junction words that are SAFE (real English words containing
# these sequences without being concatenation artefacts). Expand as
# false positives emerge.
_WORDS_WITH_EMBEDDED_CONJ = {
    # "and" — mostly safe, content words after are usually "development",
    #         "govern", "transition", etc.
    "andorra", "andante",
    # "of" — onboarding, often, office, offset, offer...
    "office", "offer", "often", "offset", "offensive", "offspring",
    "ofsted",  # UK regulator
    # "to" — today, token, total, toward, toxic...
    "today", "token", "total", "toward", "towards", "toxic", "tolerate",
    "topology", "totalitarian", "tomorrow",
    # "in" — income, industry, individual, inflation, inform...
    "income", "industry", "individual", "inflation", "inform", "initial",
    "intel", "interest", "internet", "interim", "inside", "insight",
    "install", "insta", "instance", "institute",
    # "at" — atomic, attack, attend, attempt, attract, attain, atlas, athlete...
    "atomic", "attack", "attend", "attempt", "attract", "attain", "atlas",
    "athlete", "atrium", "attrition",
    # "by" — bylaw, bypass, byproduct, byline...
    "bylaw", "bypass", "byproduct", "byline", "byword",
    # "on" — once, online, onset, only, onto, onward...
    "once", "online", "onset", "only", "onto", "onward", "ongoing",
    # "for" — forest, format, former, fortune, forward, forge, forbid...
    "forest", "format", "former", "fortune", "forward", "forge", "forbid",
    "foreign", "format", "formula",
    # "with" — within, without, withdraw, withhold
    "within", "without", "withdraw", "withhold",
    # "from" — fromage
    "fromage",
}

# ---------------------------------------------------------------------------
# Real English words ending in -our. Protects them from the "Case B"
# aggressive split that would otherwise turn "colour" into "col our".
# ---------------------------------------------------------------------------
_WORDS_ENDING_OUR = {
    "colour", "labour", "favour", "flavour", "honour", "glamour", "behaviour",
    "neighbour", "contour", "fervour", "vapour", "armour", "harbour",
    "humour", "rumour", "saviour", "endeavour", "parlour", "splendour",
    "demeanour", "ardour", "candour", "clamour", "misdemeanour",
    "paramour", "succour", "tumour", "velour", "detour", "devour",
    "pour", "sour", "tour", "hour", "four", "your", "flour", "scour",
    "amour",  # lesser-common but real
    # Compound endings that happen to end in -our but aren't targets
    "amateur",  # ends in 'eur' not 'our', but close—safeguard
}


def _fix_hyphenation(text: str) -> str:
    """Rejoin words split across line or column breaks."""
    if not text:
        return text
    text = _HYPHEN_NEWLINE_RE.sub(r"\1\2", text)
    text = _HYPHEN_MULTISPACE_RE.sub(r"\1\2", text)
    return text


def _repair_concatenated_words(text: str) -> str:
    """Split words that were incorrectly concatenated during earlier
    hyphenation removal.

    Handles patterns like 'research anddevelopment' → 'research and
    development' that appear when PDF extraction removed a linebreak
    but also swallowed the adjacent space.

    Conservative policy: only the multi-letter conjunctions "from",
    "with", "and" are considered for aggressive mid-word splitting,
    because they rarely appear inside real English words. Short
    conjunctions ("of", "to", "on", "in", "at", "by", "for") are too
    common inside real words (office, today, online, inside, atomic,
    byline, format) to split safely without a full dictionary check —
    those are handled only when the token is unambiguously a glued
    pair (e.g. token begins with "of" immediately followed by an
    uppercase letter like "ofSAF").
    """
    if not text:
        return text

    # ------------------------------------------------------------------
    # AGGRESSIVE splits — conjunctions and first-person-plural pronouns
    # that rarely appear inside real words, so start/end matches are
    # almost always artefacts.
    # ------------------------------------------------------------------
    # The possessive "our" often gets glued to the preceding verb
    # when a linebreak is stripped without a space:
    #   "deepenour alliance"    → "deepen our alliance"
    #   "supportour strategy"   → "support our strategy"
    #   "enhancesour position"  → "enhances our position"
    # Real English words ending with "our" exist (colour, labour, favour,
    # flavour, honour, glamour, behaviour, neighbour, contour, fervour,
    # vapour, armour) and are protected via the _WORDS_ENDING_OUR
    # safelist.
    AGGRESSIVE_CONJS = [
        ("from", 4),   # frommanufacturers, frominvestors
        ("with", 4),   # withregard, withchange  (careful: withhold, within, without)
        ("and", 4),    # anddevelopment, andtransition  (careful: andorra)
        ("our", 4),    # deepenour, supportour
    ]

    # ------------------------------------------------------------------
    # SAFE splits — only when conjunction-followed-by-uppercase (obvious
    # artefacts from rendering). Keeps "office", "today", "onset" intact.
    # Matches:
    #   (a) within a single token: "productionof" + next_token uppercase
    #   (b) "xxxxOfYyy" concatenation inside one token
    # In both cases, the uppercase signal is strong evidence this is a
    # rendering artefact, not a real English word.
    # ------------------------------------------------------------------
    # Pattern A: token ending in lowercase+conj, next token starting
    # with uppercase: "productionof SAF" → "production of SAF"
    TOKEN_END_CONJ_RE = re.compile(
        r"([a-z]{3,})(of|to|on|in|at|by|for)(\s+)([A-Z][a-zA-Z]+)"
    )
    # Pattern B: conjunction mid-token followed by uppercase:
    # "relatedtoMonroe" → "related to Monroe"
    MID_TOKEN_UPPERCASE_RE = re.compile(
        r"([a-z]{3,})(of|to|on|in|at|by|for)([A-Z][a-zA-Z]+)"
    )
    # Pattern C: whitespace followed by conjunction+uppercase:
    # "research andDevelopment" → "research and Development"
    START_CONJ_UPPERCASE_RE = re.compile(
        r"\b(and|from|with|of|to|on|in|at|by|for)([A-Z][a-zA-Z]+)"
    )

    def _try_aggressive_split(token: str) -> str:
        """Attempt split with from/with/and conjunctions."""
        lower = token.lower()

        if not lower.isalpha() or len(lower) < 7 or not token.islower():
            return token
        if lower in _WORDS_WITH_EMBEDDED_CONJ or lower in _CONCAT_SAFELIST:
            return token

        for conj, min_suffix in AGGRESSIVE_CONJS:
            clen = len(conj)

            # Case A: token STARTS with conjunction (anddevelopment)
            if lower.startswith(conj) and len(lower) >= clen + min_suffix:
                suffix = token[clen:]
                if (suffix.isalpha() and suffix[0].islower()
                        and len(suffix) >= min_suffix):
                    # Extra guard: "withdraw", "withhold", "within",
                    # "without", "withstand" start with "with" but are
                    # real words
                    suffix_lower = suffix.lower()
                    if conj == "with" and suffix_lower in (
                        "draw", "hold", "in", "out", "stand", "drawal",
                    ):
                        continue
                    if suffix_lower in _WORDS_WITH_EMBEDDED_CONJ:
                        continue
                    return f"{conj} {suffix}"

            # Case B: token ENDS with conjunction.
            # Safely handled only for "our" (deepen+our, support+our,
            # enhance+our). Real English -our words are rare and
            # protected via the _WORDS_ENDING_OUR safelist. "and"
            # Case B is deliberately disabled because too many real
            # words end in -and (brand, errand, demand, thousand,
            # husband, wand, errand, stand).
            if conj == "our" and lower.endswith(conj) and len(lower) >= clen + 4:
                prefix = token[:-clen]
                if prefix.isalpha() and prefix.islower() and len(prefix) >= 4:
                    # Guard: protect legitimate -our words
                    if lower not in _WORDS_ENDING_OUR:
                        # Must not also be a WORDS_WITH_EMBEDDED_CONJ
                        if lower not in _WORDS_WITH_EMBEDDED_CONJ:
                            return f"{prefix} {conj}"
            elif conj == "and" and lower.endswith(conj) and len(lower) >= clen + 3:
                pass  # deliberately disabled (too many real -and words)

        return token

    # Apply aggressive splits token-by-token (preserves punctuation)
    out_tokens = []
    for raw_token in re.split(r"(\s+)", text):
        if not raw_token or raw_token.isspace():
            out_tokens.append(raw_token)
            continue
        m = re.match(r"^([^\w]*)(.*?)([^\w]*)$", raw_token, re.DOTALL)
        if not m:
            out_tokens.append(raw_token)
            continue
        lead, core, trail = m.groups()
        if not core:
            out_tokens.append(raw_token)
            continue
        split = _try_aggressive_split(core)
        out_tokens.append(lead + split + trail)

    result = "".join(out_tokens)

    # Apply safe-uppercase splits AFTER token pass (these need regex on
    # full text, not per-token, because artefacts can span whitespace)
    result = TOKEN_END_CONJ_RE.sub(r"\1 \2\3\4", result)
    result = MID_TOKEN_UPPERCASE_RE.sub(r"\1 \2 \3", result)
    result = START_CONJ_UPPERCASE_RE.sub(r"\1 \2", result)

    return result


# ---------------------------------------------------------------------------
# Block classification
# ---------------------------------------------------------------------------
@dataclass
class TextBlock:
    """A structural unit extracted from a PDF page.

    Attributes
    ----------
    bbox : Tuple[float, float, float, float]
        (x0, y0, x1, y1) bounding box in PDF points.
    text : str
        Concatenated text of the block (already hyphenation-repaired).
    font_size : float
        Median font size of the block's spans.
    is_bold : bool
        True if majority of spans are bold-flagged.
    block_type : str
        One of: "heading", "body", "caption", "table", "label".
    column : int
        0-indexed column assignment based on x-range clustering.
    """
    bbox: Tuple[float, float, float, float]
    text: str
    font_size: float
    is_bold: bool
    block_type: str
    column: int


def _line_font_stats(line: dict) -> Tuple[float, bool, str, Tuple[float, float, float, float]]:
    """Extract (font_size, is_bold, text, bbox) from a single PyMuPDF line dict."""
    spans = line.get("spans", [])
    if not spans:
        return (0.0, False, "", (0.0, 0.0, 0.0, 0.0))
    text = "".join(s.get("text", "") for s in spans).strip()
    sizes = [s.get("size", 0) for s in spans if s.get("size", 0) > 0]
    font_size = median(sizes) if sizes else 0.0
    bold_count = sum(1 for s in spans if s.get("flags", 0) & FONT_FLAG_BOLD)
    is_bold = bold_count > (len(spans) / 2)
    bbox = tuple(line.get("bbox", (0.0, 0.0, 0.0, 0.0)))
    return (font_size, is_bold, text, bbox)


def _extract_blocks_with_metadata(page) -> List[TextBlock]:
    """Convert a PyMuPDF page into a list of classified TextBlocks.

    LINE-LEVEL CLASSIFICATION
    --------------------------
    Block-level classification (treating an entire PyMuPDF block as
    body or heading based on average font metrics) fails on layouts
    where titles and body text share a single PyMuPDF block — e.g.
    a section heading followed immediately by paragraph text, all
    arriving as one block.

    This implementation classifies each LINE independently by its
    span font size and bold flag, then regroups consecutive body
    lines into paragraphs. Headings at the top of a block are split
    off and emitted as separate TextBlocks with block_type="heading".

    Classification rules per line:
      - Font size >= 1.35 × page median body size → heading
      - Bold-weighted line at the TOP of a block (before any body text),
        length ≤ 120 chars → heading
      - Otherwise → body

    A bold line AFTER body text has started is treated as body (it's
    inline emphasis, not a structural heading).
    """
    d = page.get_text("dict")
    raw_blocks = [b for b in d.get("blocks", []) if b.get("type") == 0]

    # Page-level font statistics: median body font size sets the heading
    # threshold. Weighting all spans equally gives a stable estimate
    # because body text dominates span count.
    all_sizes: List[float] = []
    for b in raw_blocks:
        for line in b.get("lines", []):
            for span in line.get("spans", []):
                size = span.get("size", 0)
                if size > 0:
                    all_sizes.append(size)
    page_median_size = median(all_sizes) if all_sizes else 10.0
    heading_size_threshold = page_median_size * HEADING_FONT_SIZE_RATIO

    results: List[TextBlock] = []

    for raw_b in raw_blocks:
        # Classify each line in the raw block
        line_records = []  # (label, text, bbox, font_size, is_bold)
        for line in raw_b.get("lines", []):
            font_size, is_bold, text, bbox = _line_font_stats(line)
            if not text:
                continue
            # L.2 fix: size-only heading needs short + non-sentence-ending
            # to avoid THY-style emphasized body paragraphs being tagged TITLE
            if font_size >= heading_size_threshold:
                if len(text) <= 80 and not text.rstrip().endswith(('.', '!', '?')):
                    label = "heading"
                else:
                    label = "body"
            elif is_bold and len(text) <= MAX_HEADING_CHARS:
                label = "heading_candidate"
            else:
                label = "body"
            line_records.append((label, text, bbox, font_size, is_bold))

        if not line_records:
            continue

        # Resolve heading_candidates: only kept as heading if no body
        # has appeared yet in this block. Bold lines after body has
        # started are inline emphasis and are re-labeled as body.
        seen_body = False
        for i, (label, text, bbox, fs, bold) in enumerate(line_records):
            if label == "body":
                seen_body = True
            elif label == "heading_candidate":
                new_label = "body" if seen_body else "heading"
                line_records[i] = (new_label, text, bbox, fs, bold)

        # Group into sub-blocks: consecutive body lines → paragraph,
        # headings → individual heading blocks
        current_para: List[Tuple[str, Tuple, float, bool]] = []

        def flush_paragraph():
            """Emit the accumulated body lines as one TextBlock."""
            if not current_para:
                return
            combined = "\n".join(t for t, _, _, _ in current_para)
            combined = _fix_hyphenation(combined)
            combined = _repair_concatenated_words(combined)
            combined = repair_pdf_text(combined)  # L.3: NFKC + ligature + OCR
            combined = combined.strip()
            if not combined:
                return

            bboxes = [bb for _, bb, _, _ in current_para]
            x0 = min(bb[0] for bb in bboxes)
            y0 = min(bb[1] for bb in bboxes)
            x1 = max(bb[2] for bb in bboxes)
            y1 = max(bb[3] for bb in bboxes)
            sizes = [fs for _, _, fs, _ in current_para if fs > 0]
            font_size = median(sizes) if sizes else page_median_size
            bold_count = sum(1 for _, _, _, b in current_para if b)
            is_bold = bold_count > (len(current_para) / 2)

            block_type = "label" if len(combined) < MIN_BODY_CHARS else "body"

            results.append(TextBlock(
                bbox=(x0, y0, x1, y1),
                text=combined,
                font_size=float(font_size),
                is_bold=bool(is_bold),
                block_type=block_type,
                column=0,
            ))

        for label, text, bbox, fs, bold in line_records:
            if label == "heading":
                flush_paragraph()
                current_para = []
                # Emit heading as its own block
                heading_text = _fix_hyphenation(text)
                heading_text = _repair_concatenated_words(heading_text)
                heading_text = repair_pdf_text(heading_text).strip()  # L.3
                if heading_text:
                    results.append(TextBlock(
                        bbox=tuple(bbox),
                        text=heading_text,
                        font_size=float(fs),
                        is_bold=bool(bold),
                        block_type="heading",
                        column=0,
                    ))
            else:  # body
                current_para.append((text, bbox, fs, bold))

        flush_paragraph()

    _assign_columns(results)
    return results


def _assign_columns(blocks: List[TextBlock]) -> None:
    """Assign each block a column index based on x-position clustering.

    Simple algorithm: cluster blocks by x0 (left edge). If two consistent
    centres emerge (2-column), blocks left of the midpoint get column=0
    and right of it column=1. For 1-column pages, all blocks get column=0.

    Mutates blocks in place.
    """
    if not blocks:
        return

    x0_values = sorted(b.bbox[0] for b in blocks)
    if len(x0_values) < 4:
        return  # too few blocks to cluster

    x_min, x_max = x0_values[0], x0_values[-1]
    spread = x_max - x_min
    if spread < 100:  # narrow spread → single column
        return

    # Find the largest gap in the sorted x0 list
    gaps = [(x0_values[i + 1] - x0_values[i], i) for i in range(len(x0_values) - 1)]
    largest_gap, gap_idx = max(gaps)

    # If the largest gap is less than 20% of the page spread, it's
    # probably just natural variation, not a column boundary
    if largest_gap < spread * 0.20:
        return

    column_boundary = (x0_values[gap_idx] + x0_values[gap_idx + 1]) / 2
    for b in blocks:
        b.column = 0 if b.bbox[0] < column_boundary else 1


# ---------------------------------------------------------------------------
# Block → reading-order text
# ---------------------------------------------------------------------------
def _blocks_to_text(blocks: List[TextBlock]) -> str:
    """Serialize classified blocks to a single string in reading order.

    Reading order rules:
      1. Column 0 blocks first (sorted by y0), then column 1 blocks.
         Exception: if a block spans both columns (wide bbox), treat it
         as top-of-page and put it before both columns.
      2. Heading blocks are prefixed with a sentinel marker "¶TITLE¶\n"
         that spaCy will treat as a paragraph boundary, then stripped
         after segmentation.
      3. Body blocks are separated by double newlines, enforcing
         paragraph boundaries so spaCy won't merge across them.
      4. Label blocks (short fragments) are dropped entirely — they
         don't contribute codable sentences.
    """
    # Separate wide/full-page blocks (usually titles, page headers)
    page_width = max((b.bbox[2] for b in blocks), default=0)
    wide_threshold = page_width * 0.75

    wide_blocks: List[TextBlock] = []
    col0_blocks: List[TextBlock] = []
    col1_blocks: List[TextBlock] = []
    for b in blocks:
        block_width = b.bbox[2] - b.bbox[0]
        if block_width >= wide_threshold:
            wide_blocks.append(b)
        elif b.column == 0:
            col0_blocks.append(b)
        else:
            col1_blocks.append(b)

    # Sort each group top-to-bottom
    wide_blocks.sort(key=lambda b: b.bbox[1])
    col0_blocks.sort(key=lambda b: b.bbox[1])
    col1_blocks.sort(key=lambda b: b.bbox[1])

    ordered = wide_blocks + col0_blocks + col1_blocks

    # Serialize
    parts: List[str] = []
    for b in ordered:
        if b.block_type == "label":
            continue  # drop — not codable
        if b.block_type == "heading":
            # Paragraph-break sentinel — spaCy won't merge across this
            parts.append(f"\n\n¶TITLE¶ {b.text}\n\n")
        else:  # body
            parts.append(b.text + "\n\n")

    return "".join(parts)


# ---------------------------------------------------------------------------
# Public API — drop-in replacement for extract_pdf_text_by_page
# ---------------------------------------------------------------------------
def extract_pdf_text_hybrid(
    pdf_path: Path,
    max_pages: int = 300,
) -> List[Tuple[int, str]]:
    """Extract page-by-page text using the hybrid PyMuPDF pipeline.

    Returns a list of (page_number, text) tuples. The text preserves
    paragraph boundaries via double-newlines; heading blocks are prefixed
    with the sentinel "¶TITLE¶" which downstream sentence extraction
    strips AND uses as a sentence-boundary signal.

    If PyMuPDF is unavailable, returns [] so the caller can fall back to
    the classic pipeline.
    """
    pdf_path = Path(pdf_path)
    if not FITZ_AVAILABLE:
        return []

    pages: List[Tuple[int, str]] = []
    try:
        doc = fitz.open(str(pdf_path))
        n = min(len(doc), max_pages)
        for i in range(n):
            try:
                blocks = _extract_blocks_with_metadata(doc[i])
                text = _blocks_to_text(blocks)
                if text.strip():
                    pages.append((i + 1, text))
            except Exception as e:
                logger.debug(f"Hybrid page {i+1} failed: {e}")
        doc.close()
    except Exception as e:
        logger.warning(f"PyMuPDF failed on {pdf_path.name}: {e}")
        return []

    return pages


def extract_pdf_blocks_hybrid(
    pdf_path: Path,
    max_pages: int = 300,
) -> List[Tuple[int, List[TextBlock]]]:
    """Extract page-by-page TextBlocks with full font + layout metadata.

    Public counterpart to ``extract_pdf_text_hybrid``. Where that
    function returns serialized text per page (for sentence
    segmentation downstream), this function exposes the underlying
    classified ``TextBlock`` list per page — preserving font_size,
    is_bold, block_type ("heading"/"body"/"label"), bbox, and column
    metadata.

    Added in Tur N.2 (Frozen #87 candidate) to serve
    ``klopen.section_detect.heuristic.extract_heuristic_headings``,
    which needs structural block metadata (not just text) to infer
    heading hierarchies from PDFs without a native outline.

    Parameters
    ----------
    pdf_path : Path
        Path to the source PDF.
    max_pages : int
        Hard cap on page count to process. Default 300 matches
        ``extract_pdf_text_hybrid``.

    Returns
    -------
    list of (page_num, list of TextBlock)
        Page-indexed (1-based) list of classified blocks in extraction
        order. Empty list on failure or if PyMuPDF is unavailable.
        Individual page failures yield an empty block list for that
        page (rather than dropping the page entirely), so callers can
        iterate by page index without surprise.
    """
    pdf_path = Path(pdf_path)
    if not FITZ_AVAILABLE:
        return []

    pages: List[Tuple[int, List[TextBlock]]] = []
    try:
        doc = fitz.open(str(pdf_path))
        n = min(len(doc), max_pages)
        for i in range(n):
            try:
                blocks = _extract_blocks_with_metadata(doc[i])
                pages.append((i + 1, blocks))
            except Exception as e:  # noqa: BLE001
                logger.debug(f"Hybrid page {i+1} block extract failed: {e}")
                pages.append((i + 1, []))
        doc.close()
    except Exception as e:  # noqa: BLE001
        logger.warning(f"PyMuPDF failed on {pdf_path.name} (blocks): {e}")
        return []

    return pages


def strip_title_sentinels(text: str) -> str:
    """Remove ¶TITLE¶ sentinels from already-segmented text.

    Called after spaCy segmentation. The sentinel forces paragraph
    boundaries but has no role in the final sentence text.
    """
    if not text:
        return ""
    return text.replace("¶TITLE¶", "").strip()


def is_title_block(sentence_text: str) -> bool:
    """Return True if the sentence came from a heading block and should
    be filtered out before coding.

    Heuristic: sentence contains the ¶TITLE¶ sentinel (before stripping).
    The sentence_extraction pipeline should test this before the
    sentinel is stripped.
    """
    return "¶TITLE¶" in (sentence_text or "")