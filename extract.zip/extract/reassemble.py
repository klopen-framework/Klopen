"""
klopen/extract/reassemble.py

Heuristic line merger for ExtractedSentence sequences produced by
extract_sentences_from_pdf. Post-processes 5 segmentation patterns observed
in real-world Turkish regulatory PDFs (SHT-18 baseline, 2026-05-09).

Faz 3.5 Tur H.1 frozen decisions (v11):
  H.1-1 (a) API:        list[ExtractedSentence] -> list[ExtractedSentence]
  H.1-2 (b) Rule set:   ordered plug-in list of plain rule functions
  H.1-3 (a) Identity:   merged sentence inherits first piece's page;
                        sentence_index re-numerated 0..N-1; hash recomputed;
                        original hashes are lost (audit goes via H.1-4)
  H.1-4 (c) Drop trail: optional `dropped_collector` kwarg; default silent
  H.1-5 (a) Multi-page: first piece's page wins

Faz 3.5 Tur H.2 (v12) additions:
  - rule_drop_header_footer accepts keyword-only `header_tokens` and
    `min_token_count` (Frozen #38 preserved via functools.partial).
  - LANGUAGE_AGNOSTIC_RULES: subset omitting drop_header_footer for
    safe-fallback use in extract_sentences_from_pdf when no preset is
    supplied (H.2-3 a).

Zero external deps (frozen #15): only stdlib.
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import replace
from enum import Enum, auto
from typing import TYPE_CHECKING, Callable, List, NamedTuple, Optional, Sequence, Union

if TYPE_CHECKING:
    # Lazy / type-only — actual class used at runtime is whatever the caller
    # passes in (dataclasses.replace dispatches on instance.__class__).
    from klopen.extract.sentences import ExtractedSentence

_logger = logging.getLogger(__name__)


# -----------------------------------------------------------------------------
# Decision protocol
# -----------------------------------------------------------------------------

class MergeDecision(Enum):
    """What a rule wants to do at a given sentence index."""
    KEEP = auto()                 # No action; default
    MERGE_WITH_PREVIOUS = auto()  # Fold sentences[idx] into output's last item
    DROP = auto()                 # Remove sentences[idx]; collect for audit
    MUTATE_TEXT = auto()          # Keep sentence, replace text (Faz 4 I.1b, frozen #53)


class RuleResult(NamedTuple):
    """Rule return value — frozen #53 algebra extension.

    Backward compat: rules may return MergeDecision directly; reassemble
    core wraps it as RuleResult(decision, None).

    Semantics by decision:
      KEEP                  : mutated_text ignored
      DROP                  : mutated_text ignored
      MUTATE_TEXT           : mutated_text REQUIRED — sentence output'a eklenir
                              AMA text=mutated_text, hash recomputed (frozen #11
                              identity korunur: page, sentence_index re-numerated)
      MERGE_WITH_PREVIOUS   : mutated_text OPTIONAL —
                              if None : output[-1] + current = concat (eski davranış)
                              if str  : output[-1].text = mutated_text, sonra
                                        + current = concat (Y₂ subtitle strip
                                        + body merge paterni)
    """
    decision: MergeDecision
    mutated_text: Optional[str] = None


RuleFn = Callable[[Sequence["ExtractedSentence"], int], Union[MergeDecision, RuleResult]]
"""
A rule function takes the full input list (read-only by convention) and the
current index, returning a MergeDecision OR RuleResult.

Backward compat (pre-v4 rules): return MergeDecision; core normalizes.
v4+ rules with text mutation: return RuleResult(decision, mutated_text).

Reassemble walks indices in order; the first rule to return a non-KEEP
decision wins (short-circuit). Rules inspect the ORIGINAL input, not the
running output — keeps them composable, testable, and order-stable.
"""


def _normalize_rule_return(value: Union[MergeDecision, RuleResult]) -> RuleResult:
    """Backward compat: MergeDecision → RuleResult(decision, None)."""
    if isinstance(value, MergeDecision):
        return RuleResult(value, None)
    return value


# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------

_TERMINAL_PUNCT = (".", "!", "?", "…")

# 32-char hex (md5 / short hashes commonly leaked from PDF footers)
_HEX32_RE = re.compile(r"^[0-9a-fA-F]{32}$")

# Isolated page-number patterns: "1 / 17", "1/17"
_PAGE_NUMBER_RE = re.compile(r"^\s*\d+\s*/\s*\d+\s*$")

# Numbered list marker: "1)", "2)", " 12 )"
_LIST_MARKER_RE = re.compile(r"^\s*\d+\s*\)\s*")

# Alphabetic sub-marker: "a)", "b)", Turkish letters included
_ALPHA_MARKER_RE = re.compile(r"^\s*[a-zçğıöşü]\s*\)\s*", re.IGNORECASE)

# Header/footer telltale tokens; require ≥2 to fire
_HEADER_FOOTER_TOKENS = (
    "yayım tarihi",
    "yayim tarihi",
    "değişiklik no",
    "degisiklik no",
    "değişiklik tarihi",
    "degisiklik tarihi",
)


# MADDE body fragment regex — Faz 4 I.1b Y₂ pattern detection
# Body fragment'i 'N-' (number-dash) ile başlar: "45- (1) İşletici..."
_MADDE_BODY_RE = re.compile(r"^\d+\s*[-–]\s*\(\d+\)\s+")

# Y₂ subtitle fragment ending detection: "...MADDE" veya "...MADDE N-"
# Subtitle fragment "MADDE" sözcüğü ile biter (lookahead için)
_SUBTITLE_ENDS_WITH_MADDE_RE = re.compile(r"\bMADDE\s*$|\bMADDE\s+\d+\s*[-–]\s*$|\bMADDE\s+\d+\s*[-–]\s*\(\d+\)\s*$")

# -----------------------------------------------------------------------------
# Drop rules (Kalıp 4)
# -----------------------------------------------------------------------------

def rule_drop_hex_hash(sentences: Sequence["ExtractedSentence"], idx: int) -> MergeDecision:
    """Kalıp 4: Drop standalone 32-char hex strings (footer hash artefacts)."""
    text = sentences[idx].text.strip()
    if _HEX32_RE.match(text):
        return MergeDecision.DROP
    return MergeDecision.KEEP


def rule_drop_header_footer(
    sentences: Sequence["ExtractedSentence"],
    idx: int,
    *,
    header_tokens: Optional["frozenset[str]"] = None,
    min_token_count: int = 2,
) -> MergeDecision:
    """Kalıp 4: Drop header/footer lines.

    Heuristic (conservative, all conditions required):
      - line length ≤ 100 chars
      - does NOT end with terminal punctuation (real headers don't)
      - either ≥`min_token_count` header-footer tokens hit, OR matches
        isolated page-number.

    Args:
        header_tokens: Optional frozenset of lowercase token strings. If
            None, falls back to module-level `_HEADER_FOOTER_TOKENS`
            (Turkish SHT baseline). YAML preset paths (H.2) pass a
            frozenset built from the preset's `params.header_tokens` list.
        min_token_count: Minimum number of distinct token hits required to
            fire DROP. Default 2 matches the H.1 baseline.

    NOTE on signature change (H.2-4 a, frozen #38):
        The kwargs are keyword-only; the (sequence, idx) positional contract
        is preserved. `functools.partial(rule_drop_header_footer, **kwargs)`
        produces a RuleFn-compatible callable. The unparameterized call
        `rule_drop_header_footer(sentences, idx)` still works (defaults).
    """
    text = sentences[idx].text.strip()
    if len(text) > 100:
        return MergeDecision.KEEP
    if text.endswith(_TERMINAL_PUNCT):
        return MergeDecision.KEEP

    tokens = _HEADER_FOOTER_TOKENS if header_tokens is None else header_tokens
    lower = text.lower()
    if sum(1 for tok in tokens if tok in lower) >= min_token_count:
        return MergeDecision.DROP

    if _PAGE_NUMBER_RE.match(text):
        return MergeDecision.DROP

    return MergeDecision.KEEP


# -----------------------------------------------------------------------------
# Merge rules (Kalıp 1, 2, 3, 5)
# -----------------------------------------------------------------------------

def rule_merge_after_colon(sentences: Sequence["ExtractedSentence"], idx: int) -> MergeDecision:
    """Kalıp 1: previous sentence ends with ':' → heading + body split.

    Example:
        [13] c) Birim yükleme ünitesi:
        [14] Overpack haricinde her türlü yük konteyneri, ...
        → "c) Birim yükleme ünitesi: Overpack haricinde ..."
    """
    if idx == 0:
        return MergeDecision.KEEP
    prev = sentences[idx - 1].text.rstrip()
    if prev.endswith(":"):
        return MergeDecision.MERGE_WITH_PREVIOUS
    return MergeDecision.KEEP


def rule_merge_numbered_list_item(
    sentences: Sequence["ExtractedSentence"], idx: int
) -> MergeDecision:
    """Kalıp 3: Numbered list items '1)', '2)', ... split across lines.

    Heuristic: current starts with 'N)' AND (previous also starts with 'N)'
    OR previous does not end with terminal punct).
    """
    if idx == 0:
        return MergeDecision.KEEP
    cur = sentences[idx].text.lstrip()
    if not _LIST_MARKER_RE.match(cur):
        return MergeDecision.KEEP
    prev = sentences[idx - 1].text.rstrip()
    if not prev:
        return MergeDecision.KEEP
    prev_starts_list = bool(_LIST_MARKER_RE.match(prev.lstrip()))
    if prev_starts_list or not prev.endswith(_TERMINAL_PUNCT):
        return MergeDecision.MERGE_WITH_PREVIOUS
    return MergeDecision.KEEP


def rule_merge_alphabetic_subitem(
    sentences: Sequence["ExtractedSentence"], idx: int
) -> MergeDecision:
    """Kalıp 5: Multi-subitem sentences split at 'a)', 'b)', 'c)' markers.

    Heuristic: current starts with single-alpha marker AND previous does not
    end with terminal punct. Conservative: only single-letter (no 'aa)' etc).
    """
    if idx == 0:
        return MergeDecision.KEEP
    cur = sentences[idx].text.lstrip()
    if not _ALPHA_MARKER_RE.match(cur):
        return MergeDecision.KEEP
    prev = sentences[idx - 1].text.rstrip()
    if not prev:
        return MergeDecision.KEEP
    if not prev.endswith(_TERMINAL_PUNCT):
        return MergeDecision.MERGE_WITH_PREVIOUS
    return MergeDecision.KEEP


def rule_merge_after_comma(sentences: Sequence["ExtractedSentence"], idx: int) -> MergeDecision:
    """Continuation: previous sentence ends with comma — universally never a sentence ending.

    Language-agnostic: no real sentence ends with ','. Independent of next-line
    capitalization, which is why this catches cases that lowercase_continuation
    misses (e.g. SHT-18 [13]→[14]: '...,' followed by 'Uluslararası ...').

    Placed before lowercase_continuation in DEFAULT_RULES; both would return
    the same decision when both fire, but comma fires the more informative
    log line.
    """
    if idx == 0:
        return MergeDecision.KEEP
    prev = sentences[idx - 1].text.rstrip()
    if prev.endswith(","):
        return MergeDecision.MERGE_WITH_PREVIOUS
    return MergeDecision.KEEP


def rule_merge_lowercase_continuation(
    sentences: Sequence["ExtractedSentence"], idx: int
) -> MergeDecision:
    """Kalıp 2: page break / line break swallowed mid-sentence.

    Heuristic: previous does NOT end with terminal punct AND current's first
    alphabetic char is lowercase. Most permissive rule — placed last.

    Example:
        [2] MADDE 2- (1) Bu Talimat sivil havacılık alanında ... taşınmasında
        [3] yer alan gerçek ve tüzel kişileri kapsar.
    """
    if idx == 0:
        return MergeDecision.KEEP
    prev = sentences[idx - 1].text.rstrip()
    cur = sentences[idx].text.lstrip()
    if not prev or not cur:
        return MergeDecision.KEEP
    if prev.endswith(_TERMINAL_PUNCT):
        return MergeDecision.KEEP
    first_alpha = next((ch for ch in cur if ch.isalpha()), None)
    if first_alpha is None:
        return MergeDecision.KEEP
    if first_alpha.islower():
        return MergeDecision.MERGE_WITH_PREVIOUS
    return MergeDecision.KEEP


# -----------------------------------------------------------------------------
# Default rule pipeline (order matters)
# -----------------------------------------------------------------------------

DEFAULT_RULES: tuple[RuleFn, ...] = (
    # Drops first (cheap, decisive — hash/header lines should never reach merge)
    rule_drop_hex_hash,
    rule_drop_header_footer,
    # Merges, specific → general
    rule_merge_after_colon,
    rule_merge_numbered_list_item,
    rule_merge_alphabetic_subitem,
    rule_merge_after_comma,
    rule_merge_lowercase_continuation,
)

# Language-agnostic subset (excludes rule_drop_header_footer which uses
# Turkish-specific token list). Used as the default fallback in
# `extract_sentences_from_pdf` when no `segmentation_preset` is provided
# (Faz 3.5 H.2-3 a).
#
# For Turkish regulatory PDFs (SHT serisi etc.), load the
# `turkish_regulations.yaml` preset to enable token-based header drops.
# For other languages, write/load a domain-specific preset that supplies
# `header_tokens` for that document family.
LANGUAGE_AGNOSTIC_RULES: tuple[RuleFn, ...] = (
    rule_drop_hex_hash,
    rule_merge_after_colon,
    rule_merge_numbered_list_item,
    rule_merge_alphabetic_subitem,
    rule_merge_after_comma,
    rule_merge_lowercase_continuation,
)


# -----------------------------------------------------------------------------
# Reassembler core
# -----------------------------------------------------------------------------

def _hash_text(text: str) -> str:
    """Recompute md5 over UTF-8 bytes (matches sentences.py convention)."""
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def _merge_text(prev_text: str, cur_text: str) -> str:
    """Concatenate prev + cur with a single space; collapse boundary whitespace.

    Special case: if prev ends with '-' AND cur starts with a lowercase alpha,
    treat as Turkish hyphenated line-break and stitch ('keli-' + 'menin' →
    'kelimenin').
    """
    left = prev_text.rstrip()
    right = cur_text.lstrip()
    if not right:
        return left
    if not left:
        return right
    if left.endswith("-"):
        first_alpha = next((ch for ch in right if ch.isalpha()), None)
        if first_alpha is not None and first_alpha.islower():
            return left[:-1] + right
    return f"{left} {right}"


def reassemble(
    sentences: List["ExtractedSentence"],
    *,
    rules: Sequence[RuleFn] = DEFAULT_RULES,
    dropped_collector: Optional[List["ExtractedSentence"]] = None,
) -> List["ExtractedSentence"]:
    """Post-process an extracted sentence list, applying merge/drop rules.

    Args:
        sentences: Raw extracted sentences in document order.
        rules: Ordered plug-in rule functions. First non-KEEP decision wins
            per index. Defaults to DEFAULT_RULES (5-pattern Turkish baseline).
        dropped_collector: Optional list to receive dropped originals for
            audit. Default None ⇒ silent drop with `_logger.debug`.

    Returns:
        New list of ExtractedSentence with:
          - Merged sentences inherit first piece's page (H.1-5 a).
          - sentence_index re-numerated 0..N-1.
          - hash recomputed over new text.
          - Other fields preserved from first piece via dataclasses.replace
            (forward-compatible if ExtractedSentence grows fields, frozen #11
            kept minimum at the call site).
    """
    if not sentences:
        return []

    output: List["ExtractedSentence"] = []
    drop_count = 0
    merge_count = 0

    mutate_count = 0

    for idx, sent in enumerate(sentences):
        result: RuleResult = RuleResult(MergeDecision.KEEP, None)
        firing_rule_name: Optional[str] = None
        for rule in rules:
            raw = rule(sentences, idx)
            res = _normalize_rule_return(raw)
            if res.decision is not MergeDecision.KEEP:
                result = res
                firing_rule_name = getattr(rule, "__name__", None) or getattr(
                    getattr(rule, "func", None), "__name__", repr(rule)
                )
                break  # First non-KEEP wins (short-circuit)

        decision = result.decision
        mutated = result.mutated_text

        if decision is MergeDecision.DROP:
            if dropped_collector is not None:
                dropped_collector.append(sent)
            else:
                _logger.debug(
                    "reassemble: drop idx=%d rule=%s text=%r",
                    idx, firing_rule_name, sent.text[:80],
                )
            drop_count += 1
            continue

        if decision is MergeDecision.MUTATE_TEXT:
            # Frozen #53: text replace, identity korunur (page, hash recomputed,
            # sentence_index re-numerated below in final pass).
            if mutated is None:
                raise ValueError(
                    f"MUTATE_TEXT requires mutated_text (rule={firing_rule_name}, idx={idx})"
                )
            output.append(replace(
                sent,
                text=mutated,
                hash=_hash_text(mutated),
            ))
            _logger.debug(
                "reassemble: mutate idx=%d rule=%s new_text=%r",
                idx, firing_rule_name, mutated[:80],
            )
            mutate_count += 1
            continue

        if decision is MergeDecision.MERGE_WITH_PREVIOUS and output:
            head = output[-1]
            # Frozen #53: optional mutated_text = previous'u replace ile öncelikli
            if mutated is not None:
                prev_text_for_merge = mutated
            else:
                prev_text_for_merge = head.text
            new_text = _merge_text(prev_text_for_merge, sent.text)
            output[-1] = replace(
                head,
                text=new_text,
                hash=_hash_text(new_text),
                # page intentionally NOT touched (H.1-5 a: first piece wins).
                # sentence_index will be re-numerated below in final pass.
            )
            _logger.debug(
                "reassemble: merge idx=%d rule=%s into out_idx=%d mutated=%s",
                idx, firing_rule_name, len(output) - 1, mutated is not None,
            )
            merge_count += 1
            continue

        # KEEP, or MERGE_WITH_PREVIOUS at idx=0 (degenerate → keep)
        output.append(sent)

    # Re-numerate sentence_index 0..N-1 (H.1-3 a)
    final = [replace(s, sentence_index=i) for i, s in enumerate(output)]

    _logger.info(
        "reassemble: %d → %d sentences (merged=%d, dropped=%d, mutated=%d)",
        len(sentences), len(final), merge_count, drop_count, mutate_count,
    )
    return final


# -----------------------------------------------------------------------------
# Subtitle drop rule (Faz 4 I.1a)
# -----------------------------------------------------------------------------

def rule_drop_subtitle_when_alone(
    sentences: Sequence["ExtractedSentence"],
    idx: int,
    *,
    subtitle_tokens: Optional["frozenset[str]"] = None,
    max_text_length: int = 100,
) -> MergeDecision:
    """Faz 4 I.1a: Drop lone subtitle lines (with or without MADDE-prefix fragment).

    Heuristic (all conditions required):
      - line length ≤ `max_text_length` chars (default 100)
      - line lowercase startswith one of `subtitle_tokens`, with WORD BOUNDARY
        (next char must be whitespace or end-of-string) — prevents partial
        matches like "tanımlar" matching "tanımlarımız"
      - line does NOT end with terminal punct (true sentences are protected)
      - line does NOT end with ':' (colon → definition pattern, handled by
        rule_merge_after_colon; do NOT drop "Gümrüklü geçici depolama: ...")

    Examples (SHT-18 raw):
      "Yolcuların bilgilendirilmesi MADDE 46-"                    → DROP
      "Uçuş ekibinin bilgilendirilmesi ve talimatlar MADDE"       → DROP
      "Gümrüklü geçici depolama...sorumlulukları MADDE 43- (1)"   → DROP (78 char)
      "Gümrüklü geçici depolama alanı ... hizmetleri işletmesi:"  → KEEP (colon)
      "Tanımlar MADDE 4- (1) Bu Talimatta geçen..."               → KEEP (>80 char)
      "(2) ...yer almayan tanımlar için..."                       → KEEP (not startswith)

    Mixed Y₁ pattern (başlık + MADDE + gövde >80 char tek cümle) bu rule ile
    çözülmez — Faz 4 I.1b strip_subtitle_prefix (MUTATE_TEXT, frozen #53) gerekir.

    Args:
        subtitle_tokens: Optional frozenset of lowercase subtitle prefix strings.
            If None, no drop fires (defensive default; preset MUST supply).
        max_text_length: Conservative length cap. SHT-18'in en uzun
            başlık+MADDE-prefix fragment'i 90 char ("Gümrüklü geçici depolama
            ve antrepo hizmetleri işletmelerinin sorumlulukları MADDE 43- (1)").
            100 default, drop_header_footer rule'un len cap'i ile simetrik
            (frozen #18 default-off konvansiyonu); YAML preset override edebilir.
            Body cümleleri SHT-18 ortalama 200+ char olduğu için false positive
            riski düşük.
    """
    text = sentences[idx].text.strip()
    if len(text) > max_text_length:
        return MergeDecision.KEEP
    if text.endswith(_TERMINAL_PUNCT):
        return MergeDecision.KEEP
    if text.endswith(":"):
        return MergeDecision.KEEP
    if subtitle_tokens is None:
        return MergeDecision.KEEP

    # _starts_with_subtitle Turkish-aware (İ → i normalization)
    if _starts_with_subtitle(text, subtitle_tokens) is not None:
        return MergeDecision.DROP

    return MergeDecision.KEEP

# -----------------------------------------------------------------------------
# Subtitle prefix strip + merge rules (Faz 4 I.1b, frozen #53 MUTATE_TEXT)
# -----------------------------------------------------------------------------

def _tr_lower(s: str) -> str:
    """Turkish-aware lowercase: İ → i, I → ı (locale-independent).

    Python default str.lower() converts İ (U+0130) to "i̇" (i + combining
    dot above, U+0069 U+0307), expanding length by 1 and breaking
    startswith matches against pre-normalized tokens like "işaretleme".

    Manual replace is locale-independent and preserves length invariant.
    """
    return s.replace("İ", "i").replace("I", "ı").lower()


def _starts_with_subtitle(text: str, subtitle_tokens: "frozenset[str]") -> Optional[str]:
    """Check if text Turkish-aware-lowercase startswith any subtitle token
    (word boundary). Returns matched token, or None.

    NOT: subtitle_tokens YAML'dan _tr_lower'lanmış olarak gelmeli (builder'da
    frozenset(_tr_lower(t) for t in tokens)). Bu fonksiyon text tarafında
    _tr_lower uygular.
    """
    lower = _tr_lower(text)
    for tok in subtitle_tokens:
        if lower.startswith(tok):
            tlen = len(tok)
            if tlen == len(lower) or lower[tlen] in (" ", "\t"):
                return tok
    return None


def rule_strip_subtitle_prefix(
    sentences: Sequence["ExtractedSentence"],
    idx: int,
    *,
    subtitle_tokens: Optional["frozenset[str]"] = None,
) -> RuleResult:
    """Faz 4 I.1b Y₁: Strip subtitle prefix from sentences that have body inline.

    Y₁ pattern: "Tanımlar MADDE 4- (1) Bu Talimatta geçen..."
                 ↑________↑ <- subtitle prefix (strip this)
                            ↑___ MADDE body (keep this)

    Heuristic:
      - cümle lowercase startswith bir subtitle_token + word boundary
      - subtitle prefix'ten sonra "MADDE " bulunur (yani body var)
      - prefix kesilip MADDE'den itibaren text mutate edilir

    Returns:
        RuleResult(MUTATE_TEXT, "MADDE 4- (1) ...") if Y₁ pattern matches.
        RuleResult(KEEP, None) otherwise.

    Frozen #53: MUTATE_TEXT decision, text mutate, identity korunur
                (page, sentence_index re-numerated by reassemble core).
    """
    if subtitle_tokens is None:
        return RuleResult(MergeDecision.KEEP, None)

    text = sentences[idx].text
    stripped_left = text.lstrip()
    if not stripped_left:
        return RuleResult(MergeDecision.KEEP, None)

    matched_tok = _starts_with_subtitle(stripped_left, subtitle_tokens)
    if matched_tok is None:
        return RuleResult(MergeDecision.KEEP, None)

    # Subtitle prefix'ten sonra "MADDE " var mı?
    after_subtitle = stripped_left[len(matched_tok):].lstrip()
    if not after_subtitle.upper().startswith("MADDE "):
        return RuleResult(MergeDecision.KEEP, None)

    # Mutate: original text'in başındaki subtitle prefix'i kes, MADDE ile başlat.
    # Leading whitespace varsa koru (rare, ama defensive).
    leading_ws = text[: len(text) - len(stripped_left)]
    new_text = leading_ws + after_subtitle
    return RuleResult(MergeDecision.MUTATE_TEXT, new_text)


def rule_merge_subtitle_fragment_with_previous(
    sentences: Sequence["ExtractedSentence"],
    idx: int,
    *,
    subtitle_tokens: Optional["frozenset[str]"] = None,
    max_subtitle_length: int = 100,
) -> RuleResult:
    """Faz 4 I.1b Y₂: Merge MADDE-body fragment with preceding subtitle fragment.

    Y₂ pattern (paragraph-wrap split):
      [N-1] = "Uçuş ekibinin... MADDE"            (subtitle + MADDE keyword)
      [N]   = "45- (1) İşletici..."               (number-dash body)
      → Merge into "MADDE 45- (1) İşletici..."    (subtitle stripped, MADDE preserved)

    Or:
      [N-1] = "Gümrüklü... MADDE 43- (1)"         (subtitle + MADDE prefix)
      [N]   = "Tehlikeli maddelerin..."           (body content)
      → Merge into "MADDE 43- (1) Tehlikeli..."

    Heuristic (rule fires at idx=N, body fragment):
      - idx >= 1
      - previous (idx-1) lowercase startswith subtitle_token (word boundary)
      - previous ends with "MADDE", "MADDE N-", or "MADDE N- (X)"
      - previous len ≤ max_subtitle_length (Y₂ fragment kısadır)
      - current is body content (starts with digit-dash OR plain text)
      - current does NOT itself match Y₂ pattern start (avoid cascading)

    Returns:
        RuleResult(MERGE_WITH_PREVIOUS, "MADDE [N-]"):
          mutated_text = "MADDE" + suffix from previous (numbers/parens preserved)
          reassemble core: output[-1].text = mutated_text, then concat with current.
        RuleResult(KEEP, None) otherwise.

    Frozen #53: MERGE_WITH_PREVIOUS + mutated_text (Y₂ subtitle strip + body merge).
    """
    if subtitle_tokens is None or idx == 0:
        return RuleResult(MergeDecision.KEEP, None)

    prev_text = sentences[idx - 1].text.strip()
    if not prev_text or len(prev_text) > max_subtitle_length:
        return RuleResult(MergeDecision.KEEP, None)

    matched_tok = _starts_with_subtitle(prev_text, subtitle_tokens)
    if matched_tok is None:
        return RuleResult(MergeDecision.KEEP, None)

    # Previous must end with MADDE pattern
    m = _SUBTITLE_ENDS_WITH_MADDE_RE.search(prev_text)
    if m is None:
        return RuleResult(MergeDecision.KEEP, None)

    # Extract MADDE suffix from previous: "MADDE", "MADDE 45-", "MADDE 43- (1)"
    madde_suffix = m.group(0).strip()
    # Normalize: ensure starts with "MADDE"
    if not madde_suffix.upper().startswith("MADDE"):
        return RuleResult(MergeDecision.KEEP, None)

    return RuleResult(MergeDecision.MERGE_WITH_PREVIOUS, madde_suffix)

# -----------------------------------------------------------------------------
# Smoke tests (run with: python -m klopen.extract.reassemble)
# -----------------------------------------------------------------------------

def _smoke_tests() -> None:
    """Inline smoke tests using a minimal stub of ExtractedSentence."""
    from dataclasses import dataclass

    @dataclass
    class _Stub:
        page: int
        text: str
        sentence_index: int
        hash: str

    def _mk(rows):
        """rows: list[(page, text)] → list[_Stub]."""
        return [
            _Stub(page=p, text=t, sentence_index=i, hash=_hash_text(t))
            for i, (p, t) in enumerate(rows)
        ]

    failures: list[str] = []

    def _check(name: str, condition: bool, detail: str = "") -> None:
        if condition:
            print(f"  ✓ {name}")
        else:
            failures.append(name)
            print(f"  ✗ {name}: {detail}")

    print("=== reassemble.py smoke tests ===")

    # T1
    out = reassemble([])
    _check("T1 empty input → empty output", out == [])

    # T2
    inp = _mk([(1, "Bu cümle tamdır.")])
    out = reassemble(inp)
    _check("T2 single keep + index re-num",
           len(out) == 1 and out[0].text == "Bu cümle tamdır." and out[0].sentence_index == 0)

    # T3 — Kalıp 1
    inp = _mk([
        (1, "c) Birim yükleme ünitesi:"),
        (1, "Overpack haricinde her türlü yük konteyneri, palet ve diğer ekipmanlar."),
    ])
    out = reassemble(inp)
    _check("T3 Kalıp 1 colon merge → 1 sentence", len(out) == 1)
    _check("T3 Kalıp 1 inherits first page", len(out) == 1 and out[0].page == 1)
    _check("T3 Kalıp 1 text concatenated",
           len(out) == 1 and "ünitesi: Overpack" in out[0].text)

    # T4 — Kalıp 2 across pages (H.1-5 a)
    inp = _mk([
        (1, "MADDE 2- (1) Bu Talimat sivil havacılık alanında taşınmasında"),
        (2, "yer alan gerçek ve tüzel kişileri kapsar."),
    ])
    out = reassemble(inp)
    _check("T4 Kalıp 2 lowercase merge → 1 sentence", len(out) == 1)
    _check("T4 Kalıp 2 inherits FIRST page (H.1-5 a)",
           len(out) == 1 and out[0].page == 1)
    _check("T4 Kalıp 2 ends with period",
           len(out) == 1 and out[0].text.rstrip().endswith("kapsar."))

    # T5 — Kalıp 3 chain
    inp = _mk([
        (1, "Ciddi yaralanma: 1) Hastaneye yatış gerektiren"),
        (1, "2) El, ayak parmakları kopması"),
        (1, "3) Şiddetli kanamaya yol açan"),
        (1, "4) İkinci derece yanık."),
    ])
    out = reassemble(inp)
    _check("T5 Kalıp 3 chain merge → 1 sentence", len(out) == 1, f"got {len(out)}")
    _check("T5 Kalıp 3 contains all items",
           len(out) == 1 and all(m in out[0].text for m in ("1)", "2)", "3)", "4)")))

    # T6 — Kalıp 4 hash drop with collector
    inp = _mk([
        (1, "Önceki cümle sonu."),
        (1, "5f63b6e245be55a3b15e67f483de3f6e"),
        (1, "Sonraki cümle başı."),
    ])
    dropped: list = []
    out = reassemble(inp, dropped_collector=dropped)
    _check("T6 Kalıp 4 hash dropped from output", len(out) == 2)
    _check("T6 Kalıp 4 hash captured in collector", len(dropped) == 1)
    _check("T6 Kalıp 4 collected text intact",
           len(dropped) == 1 and dropped[0].text == "5f63b6e245be55a3b15e67f483de3f6e")

    # T7 — Kalıp 4 header + page-number
    inp = _mk([
        (1, "Önceki tam cümle."),
        (1, "SHT-18 Yayım Tarihi Değişiklik No Değişiklik Tarihi Sayfa"),
        (1, "1 / 17"),
        (1, "Sonraki tam cümle."),
    ])
    out = reassemble(inp)
    _check("T7 Kalıp 4 header+page-num both dropped",
           len(out) == 2,
           f"got {len(out)}: {[s.text[:40] for s in out]}")

    # T8 — Kalıp 1+5 chained
    inp = _mk([
        (1, "Aşağıdaki şartlar aranır:"),
        (1, "a) Geçerli sertifika"),
        (1, "b) Onaylı eğitim"),
        (1, "c) Sağlık raporu."),
    ])
    out = reassemble(inp)
    _check("T8 Kalıp 1+5 chain merge → 1 sentence", len(out) == 1, f"got {len(out)}")
    _check("T8 Kalıp 5 contains all submarkers",
           len(out) == 1 and all(m in out[0].text for m in ("a)", "b)", "c)")))

    # T9 — negative: no merge after period
    inp = _mk([(1, "Birinci tam cümle."), (1, "İkinci tam cümle.")])
    out = reassemble(inp)
    _check("T9 no merge when prev ends with period", len(out) == 2)

    # T10 — idempotence
    inp = _mk([(1, "c) Tanım:"), (1, "açıklama gövdesi.")])
    out1 = reassemble(inp)
    out2 = reassemble(out1)
    _check("T10 idempotent",
           len(out1) == 1 and len(out2) == 1 and out1[0].text == out2[0].text)

    # T11 — silent drop default (no collector)
    inp = _mk([(1, "5f63b6e245be55a3b15e67f483de3f6e")])
    out = reassemble(inp)
    _check("T11 silent drop default", len(out) == 0)

    # T12 — all-drop → empty
    inp = _mk([(1, "5f63b6e245be55a3b15e67f483de3f6e"), (1, "1 / 17")])
    out = reassemble(inp)
    _check("T12 all drops → empty list", out == [])

    # T13 — hash recomputed for merged
    inp = _mk([(1, "Tanım:"), (1, "gövde.")])
    original_hash = inp[0].hash
    out = reassemble(inp)
    _check("T13 merged hash differs from any original",
           len(out) == 1 and out[0].hash != original_hash)

    # T14 — multi-page first wins (H.1-5 a)
    inp = _mk([(3, "Cümle başı"), (4, "cümle sonu.")])
    out = reassemble(inp)
    _check("T14 multi-page → first page wins", len(out) == 1 and out[0].page == 3)

    # T15 — hyphen line-break stitching
    inp = _mk([(1, "Bu metin uzun bir keli-"), (1, "menin parçasıdır.")])
    out = reassemble(inp)
    _check("T15 hyphen stitched into one word",
           len(out) == 1 and "kelimenin" in out[0].text,
           f"got: {out[0].text!r}" if out else "empty")

    # T16 — comma rule fires regardless of next-line capitalization
    inp = _mk([
        (1, "Uluslararası Sivil Havacılık Teşkilatını,"),
        (1, "Türk Sivil Havacılık Genel Müdürlüğünü ifade eder."),
    ])
    out = reassemble(inp)
    _check("T16 comma + uppercase next merges",
           len(out) == 1, f"got {len(out)}")
    _check("T16 comma merged text intact",
           len(out) == 1 and "Teşkilatını, Türk" in out[0].text)

    # T17 — comma + page break combined; first page still wins (H.1-5 a)
    inp = _mk([(1, "Birinci kısım,"), (2, "ikinci kısım sona erer.")])
    out = reassemble(inp)
    _check("T17 comma + multi-page first wins",
           len(out) == 1 and out[0].page == 1,
           f"got len={len(out)}" + (f" page={out[0].page}" if out else ""))

    print()
    if failures:
        print(f"FAILED: {len(failures)} test(s): {failures}")
        raise SystemExit(1)
    print(f"PASSED: 17/17 ✅")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s %(name)s: %(message)s")
    _smoke_tests()