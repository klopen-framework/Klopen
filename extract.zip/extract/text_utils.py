from __future__ import annotations
"""Text utilities — Unicode + PDF OCR error correction.

Klopen extract pipeline icin text repair fonksiyonlari:
  - NFKC unicode normalize (ligature, NBSP, smart quotes)
  - Ligature explicit expansion (PDF font subset'lerinde NFKC kacirir)
  - OCR substitution table (font subset encoding artifacts)

Pipeline'da hybrid.py'in flush_paragraph + heading emit noktalarinda
_fix_hyphenation sonrasinda cagrilir.

Saf, side-effect free, sira-bagimsiz.
"""
import unicodedata
import re


_LIGATURE_MAP = {
    "\ufb00": "ff",   # ff
    "\ufb01": "fi",   # fi
    "\ufb02": "fl",   # fl
    "\ufb03": "ffi",  # ffi
    "\ufb04": "ffl",  # ffl
    "\ufb05": "ft",   # ft
    "\ufb06": "st",   # st
}


_OCR_SUBSTITUTIONS = [
    ("BulIding",       "Building"),
    ("flnancial",      "financial"),
    ("flnanciai",      "financial"),
    ("Lstanbul",       "Istanbul"),
    ("pubhshed",       "published"),
    ("foliowing",      "following"),
    ("reiated",        "related"),
    ("inciudes",       "includes"),
    ("Articies",       "Articles"),
    ("Communiqu",      "Communique"),
    ("fuiflhled",      "fulfilled"),
    ("consohdated",    "consolidated"),
    ("refiecting",     "reflecting"),
    ("compiete",       "complete"),
    ("foliow",         "follow"),
    ("inciuded",       "included"),
    ("inciuding",      "including"),
    ("compieted",      "completed"),
    ("comphance",      "compliance"),
    ("rehable",        "reliable"),
    ("rehabihty",      "reliability"),
    ("Reiations",      "Relations"),
    ("reiations",      "relations"),
]

_OCR_PATTERNS = [
    (re.compile(r"\b" + re.escape(broken) + r"\b"), fixed)
    for broken, fixed in _OCR_SUBSTITUTIONS
]


def repair_pdf_text(text: str) -> str:
    """Apply NFKC + ligature + OCR substitution repairs.

    Pipeline:
      1. NFKC normalize
      2. Explicit ligature map
      3. NBSP -> regular space
      4. OCR substitution table (whole-word, case-sensitive)
    """
    if not text:
        return text
    text = unicodedata.normalize("NFKC", text)
    for lig, expansion in _LIGATURE_MAP.items():
        if lig in text:
            text = text.replace(lig, expansion)
    text = text.replace("\u00a0", " ")
    for pat, repl in _OCR_PATTERNS:
        text = pat.sub(repl, text)
    return text


def ocr_stats(text: str) -> dict:
    """Diagnostic — count which OCR patterns would fire in a text."""
    if not text:
        return {}
    out = {}
    for (pat, _), (broken, _) in zip(_OCR_PATTERNS, _OCR_SUBSTITUTIONS):
        c = len(pat.findall(text))
        if c > 0:
            out[broken] = c
    return out
