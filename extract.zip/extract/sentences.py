"""PDF -> sentence extraction with metadata.

This module handles:
    - PDF text extraction (pdfplumber preferred, PyPDF2 fallback)
    - Page-by-page processing with section tracking
    - spaCy-based sentence splitting
    - MD5 hashing for deduplication
    - Context window tracking (preceding sentences)

It does NOT apply criteria filtering. That's done in klopen.criteria.runner
based on user-defined YAML/JSON templates.

It does NOT do section detection. That's done in klopen.section_detect.detector.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import PyPDF2

logger = logging.getLogger(__name__)

try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    PDFPLUMBER_AVAILABLE = False
    logger.warning("pdfplumber not installed; falling back to PyPDF2 only")

# Hybrid extraction (PyMuPDF structure detection + paragraph-aware
# segmentation). Gracefully degrades to the classic pdfplumber pipeline if
# PyMuPDF is unavailable or hybrid module not yet ported.
try:
    from klopen.extract.hybrid import (
        extract_pdf_text_hybrid,
        strip_title_sentinels,
        is_title_block,
        FITZ_AVAILABLE,
    )
    HYBRID_AVAILABLE = FITZ_AVAILABLE
except ImportError:
    HYBRID_AVAILABLE = False

    def extract_pdf_text_hybrid(*args, **kwargs):
        return []

    def strip_title_sentinels(text: str) -> str:
        return (text or "").replace("\u00b6TITLE\u00b6", "").strip()

    def is_title_block(text: str) -> bool:
        return "\u00b6TITLE\u00b6" in (text or "")


# ---------------------------------------------------------------------------
# Column-aware extraction helpers
# ---------------------------------------------------------------------------
# PDF documents come in two fundamentally different layouts:
#
#   (A) Single-column prose (e.g., US 10-K filings, academic papers in
#       single-column format) -- pdfplumber's default left-to-right
#       top-to-bottom reading produces clean sentences.
#
#   (B) Multi-column documents (e.g., European integrated reports,
#       magazines, two-column journal articles) -- columns are separated
#       by a gutter, and pdfplumber's default extraction interleaves text
#       across columns, producing garbled sentences like
#         "Last year, the com-  highlights the firm's guidelines  pany grew."
#       where "com-" is from column A line 1, "highlights..." from column B
#       line 1, and "pany grew" from column A line 2.
#
# The solution: detect columns by analyzing word x-position histograms, then
# extract each column's text independently and concatenate in reading order.
# For single-column pages, default extraction is used (no behavior change).
#
# After column-correct reading, we also rejoin end-of-line hyphenated words
# ("state-\nment" -> "statement") which occur at column breaks.


_HYPHEN_NEWLINE_RE = re.compile(r"([a-z])-\s*\n\s*([a-z])")
_HYPHEN_MULTISPACE_RE = re.compile(r"([a-z])-\s{3,}([a-z])")


def _fix_hyphenation(text: str) -> str:
    """Rejoin words split across line or column breaks.

    Targets two patterns produced by PDF text extraction:
      1. "word-\nword"           -> "wordword"   (end-of-line hyphenation)
      2. "word-   word"          -> "wordword"   (column-gap artifact, 3+ spaces)

    Preserves legitimate compound words because they use a single space:
      - "long-term"              -> "long-term"  (unchanged)
      - "state-of-the-art"       -> "state-of-the-art" (unchanged)
    """
    if not text:
        return text
    text = _HYPHEN_NEWLINE_RE.sub(r"\1\2", text)
    text = _HYPHEN_MULTISPACE_RE.sub(r"\1\2", text)
    return text


def _detect_columns(
    page,
    min_column_gap_pt: float = 30.0,
    min_words: int = 40,
    margin_pt: float = 30.0,
) -> List[Tuple[float, float]]:
    """Detect column boundaries on a pdfplumber page.

    Returns a list of (x_min, x_max) tuples, one per detected column, sorted
    left to right. Single-column pages return [(0, page.width)].

    Algorithm
    ---------
    1. Collect word x0 (left edge) positions via page.extract_words().
    2. Bin x0 into 5pt buckets; this produces a histogram of where text
       columns BEGIN on the page.
    3. Identify "cold zones" -- contiguous bin ranges where the word count
       falls below 0.3% of all words (i.e., empty vertical bands).
    4. A cold zone is a column gutter if it is
         - at least `min_column_gap_pt` wide, and
         - located in the interior of the page (not a margin).
    5. Each interior gutter splits the page into adjacent columns.

    The algorithm is conservative: when the page has too few words, ambiguous
    layout, or only narrow gaps, it returns a single column so default
    extraction is used.
    """
    try:
        words = page.extract_words(
            x_tolerance=3, y_tolerance=3, keep_blank_chars=False
        )
    except Exception:
        return [(0.0, float(page.width))]

    if len(words) < min_words:
        return [(0.0, float(page.width))]

    page_width = float(page.width)
    bin_size = 5.0
    n_bins = int(page_width / bin_size) + 2
    hist = [0] * n_bins

    for w in words:
        idx = int(w["x0"] / bin_size)
        if 0 <= idx < n_bins:
            hist[idx] += 1

    # Cold threshold: bins with virtually no word-starts
    cold_threshold = max(2, int(len(words) * 0.003))
    # A gutter must span at least this many bins
    min_gutter_bins = int(min_column_gap_pt / bin_size)

    # Scan for cold runs
    cold_runs: List[Tuple[float, float]] = []
    i = 0
    while i < n_bins:
        if hist[i] < cold_threshold:
            start = i
            while i < n_bins and hist[i] < cold_threshold:
                i += 1
            end = i
            if end - start >= min_gutter_bins:
                cold_runs.append((start * bin_size, end * bin_size))
        else:
            i += 1

    if not cold_runs:
        return [(0.0, page_width)]

    # Keep only INTERIOR gutters (ignore left and right margins)
    interior_gutters = [
        (s, e)
        for s, e in cold_runs
        if s > margin_pt and e < page_width - margin_pt
    ]

    if not interior_gutters:
        return [(0.0, page_width)]

    # Build column boundaries from interior gutters
    columns: List[Tuple[float, float]] = []
    prev_end = 0.0
    for gutter_start, gutter_end in interior_gutters:
        columns.append((prev_end, gutter_start))
        prev_end = gutter_end
    columns.append((prev_end, page_width))

    # Filter columns too narrow to be real (< 80pt wide)
    columns = [(s, e) for s, e in columns if (e - s) >= 80.0]

    if len(columns) < 2:
        return [(0.0, page_width)]

    return columns


def _extract_words_as_text(page, columns: List[Tuple[float, float]]) -> str:
    """Reconstruct page text column by column, then line by line within each.

    For each column:
      - Filter words whose x0 falls within the column's x-range.
      - Sort top-to-bottom, then left-to-right within lines.
      - Group words into lines by y-coordinate proximity (tolerance 4pt).
      - Join columns in left-to-right order with a blank line between them.
    """
    try:
        words = page.extract_words(x_tolerance=3, y_tolerance=3)
    except Exception:
        return ""

    column_texts: List[str] = []
    for col_start, col_end in columns:
        col_words = [w for w in words if col_start <= w["x0"] < col_end]
        if not col_words:
            continue

        # Sort by top (descending y for PDF coords means top first), then x
        col_words.sort(key=lambda w: (w["top"], w["x0"]))

        # Group into lines by y-proximity
        lines: List[str] = []
        current: List[dict] = [col_words[0]]
        for w in col_words[1:]:
            if abs(w["top"] - current[-1]["top"]) < 4:
                current.append(w)
            else:
                current.sort(key=lambda ww: ww["x0"])
                lines.append(" ".join(ww["text"] for ww in current))
                current = [w]
        if current:
            current.sort(key=lambda ww: ww["x0"])
            lines.append(" ".join(ww["text"] for ww in current))

        column_texts.append("\n".join(lines))

    return "\n\n".join(column_texts)


def _extract_text_smart(page) -> str:
    """Smart page extraction: column-aware when multi-column, default otherwise.

    Safety check: if column-aware extraction produces wildly different text
    length than default (< 60% or > 140%), fall back to default -- this
    catches cases where column detection mis-fired (e.g., on tables, list
    pages, or unusual layouts).
    """
    # Default single-column extraction (baseline)
    try:
        default_text = page.extract_text() or ""
    except Exception:
        default_text = ""

    # Detect columns
    try:
        columns = _detect_columns(page)
    except Exception:
        return _fix_hyphenation(default_text)

    if len(columns) <= 1:
        return _fix_hyphenation(default_text)

    # Multi-column: reconstruct
    try:
        column_text = _extract_words_as_text(page, columns)
    except Exception:
        return _fix_hyphenation(default_text)

    # Sanity check: column text should have similar length to default text.
    if default_text:
        ratio = len(column_text) / max(len(default_text), 1)
        if ratio < 0.6 or ratio > 1.4:
            logger.debug(
                f"page column-extract length ratio {ratio:.2f} out of range; "
                f"falling back to default extraction"
            )
            return _fix_hyphenation(default_text)

    return _fix_hyphenation(column_text)


# spaCy loaded lazily (only when extraction actually happens)
_nlp = None


def _get_nlp():
    global _nlp
    if _nlp is None:
        import spacy
        try:
            _nlp = spacy.load("en_core_web_sm")
        except OSError:
            raise RuntimeError(
                "spaCy model 'en_core_web_sm' not found. "
                "Run: python -m spacy download en_core_web_sm"
            )
    return _nlp


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------
@dataclass
class ExtractedSentence:
    """A sentence extracted from a PDF with metadata.

    Klopen's core data model. Filter results, criterion matches, and any
    domain-specific fields (e.g., source document identifiers) are stored
    in `metadata` rather than as first-class attributes -- this keeps the
    model generic across domains (annual reports, academic papers, legal
    contracts, etc.).
    """
    text: str
    hash: str
    page: int
    section: str = "Intro/General"           # set by section_detector if used
    section_native: Optional[str] = None     # set by native section annotator (Frozen #84 N.1)
    tense_en: Optional[str] = None           # EN tense (Frozen #11 4. evolve, Tur N.5)
    voice_en: Optional[str] = None           # EN voice active/passive (Frozen #11 4. evolve, Tur N.5)
    zaman_tr: Optional[str] = None           # TR zaman/aspect (Frozen #11 4. evolve, Tur N.5)
    sentence_index: int = 0                   # nth sentence in document
    cohort_year: Optional[int] = None         # cohort year (Frozen #11 5. evolve, Tur N.14 N14.1.2 B1)
    cohort_company: Optional[str] = None      # cohort company (Frozen #11 5. evolve, Tur N.14 N14.1.2 B1)
    context_before: str = ""                  # preceding sentences joined by " ... "
    metadata: Dict = field(default_factory=dict)
    # Examples of metadata keys a user might populate:
    #   {"filename": "report_2024.pdf", "stem": "report_2024",
    #    "source_id": "...", "any_custom_field": "..."}

    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "hash": self.hash,
            "page": self.page,
            "section": self.section,
            "section_native": self.section_native,
            "tense_en": self.tense_en,
            "voice_en": self.voice_en,
            "zaman_tr": self.zaman_tr,
            "sentence_index": self.sentence_index,
            "cohort_year": self.cohort_year,
            "cohort_company": self.cohort_company,
            "context_before": self.context_before,
            **self.metadata,
        }


# ---------------------------------------------------------------------------
# Normalization & hashing
# ---------------------------------------------------------------------------
def normalize_text(text: str) -> str:
    """Normalize whitespace for deduplication."""
    return re.sub(r'\s+', ' ', text.strip().lower())


def sentence_hash(text: str) -> str:
    """MD5 hash of normalized text."""
    return hashlib.md5(normalize_text(text).encode('utf-8')).hexdigest()


# ---------------------------------------------------------------------------
# Near-duplicate detection (stricter than MD5 hash)
# ---------------------------------------------------------------------------
# Long-form documents often repeat the same idea across sections at different
# levels of detail. Example:
#   A: "The growth in revenue primarily results from an increased number of
#       premium offerings driven by new product launches, the continued
#       expansion of our branded product line, and strength in demand."
#   B: "The growth in revenue primarily results from the continued expansion
#       of our branded product line and strength in demand."
# MD5 hashes differ but these are functionally the same. We detect this
# with token-bigram Jaccard similarity. When two sentences exceed the
# threshold, we keep the LONGER one (more informative) and drop the other.

_COMPARE_NORM_RE = re.compile(r'[^\w\s]')
_COMPARE_WS_RE = re.compile(r'\s+')


def _normalize_for_comparison(text: str) -> str:
    """Lowercase, strip punctuation, collapse whitespace."""
    text = text.lower()
    text = _COMPARE_NORM_RE.sub(' ', text)
    text = _COMPARE_WS_RE.sub(' ', text)
    return text.strip()


def _token_bigrams(text: str) -> frozenset:
    """Return set of token bigrams of normalized text."""
    tokens = text.split()
    if len(tokens) < 2:
        return frozenset([tuple(tokens)]) if tokens else frozenset()
    return frozenset(
        (tokens[i], tokens[i + 1]) for i in range(len(tokens) - 1)
    )


def _jaccard(a: frozenset, b: frozenset) -> float:
    """Jaccard similarity of two sets."""
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    inter = len(a & b)
    union = len(a | b)
    return inter / union if union else 0.0


def _containment(smaller: frozenset, larger: frozenset) -> float:
    """Asymmetric: what fraction of `smaller` is contained in `larger`."""
    if not smaller:
        return 1.0
    inter = len(smaller & larger)
    return inter / len(smaller)


def _is_near_duplicate(
    a_grams: frozenset,
    b_grams: frozenset,
    jaccard_threshold: float = 0.75,
    containment_threshold: float = 0.85,
) -> bool:
    """Two metrics combined:

    1. Jaccard >= 0.75 -- catches sentences of similar length and content.
    2. Containment(shorter, longer) >= 0.85 -- catches sentences where one is
       a semantic subset of the other.
    """
    if _jaccard(a_grams, b_grams) >= jaccard_threshold:
        return True
    # Containment: identify smaller/larger by bigram-set size
    if len(a_grams) <= len(b_grams):
        return _containment(a_grams, b_grams) >= containment_threshold
    else:
        return _containment(b_grams, a_grams) >= containment_threshold


def _filter_near_duplicates(
    sentences: List[ExtractedSentence],
    threshold: float = 0.75,
) -> List[ExtractedSentence]:
    """Drop near-duplicate sentences (bigram Jaccard >= threshold).

    When a near-duplicate pair is found, keep the sentence with MORE tokens
    (more informative); drop the shorter one.

    Optimization: group candidates by length bucket to avoid O(n^2) across
    very different-length sentences.
    """
    if not sentences:
        return sentences

    # Precompute bigrams and normalized lengths.
    enriched = []
    for i, s in enumerate(sentences):
        norm = _normalize_for_comparison(s.text)
        tokens = norm.split()
        grams = _token_bigrams(norm)
        enriched.append((i, s, tokens, grams))

    # Sort by token length descending so we process longer sentences first.
    enriched.sort(key=lambda x: -len(x[2]))

    kept_indices = set()
    kept_grams: List[frozenset] = []
    kept_lens: List[int] = []

    drop_count = 0
    for _, s, tokens, grams in enriched:
        n = len(tokens)
        is_dup = False
        for kgrams, klen in zip(kept_grams, kept_lens):
            shorter = min(n, klen)
            longer = max(n, klen)
            if longer > 0 and shorter / longer < 0.30:
                continue
            if _is_near_duplicate(grams, kgrams,
                                  jaccard_threshold=threshold,
                                  containment_threshold=0.85):
                is_dup = True
                break
        if is_dup:
            drop_count += 1
            continue
        kept_indices.add(id(s))
        kept_grams.append(grams)
        kept_lens.append(n)

    if drop_count > 0:
        logger.info(
            f"near-duplicate filter: dropped {drop_count} of "
            f"{len(sentences)} ({drop_count / len(sentences):.1%})"
        )

    # Preserve original order while filtering
    return [s for s in sentences if id(s) in kept_indices]


# ---------------------------------------------------------------------------
# PDF text extraction
# ---------------------------------------------------------------------------
def extract_pdf_text_by_page(
    pdf_path: Path,
    max_pages: int = 300,
    mode: str = "hybrid",
) -> List[Tuple[int, str]]:
    """Extract text page-by-page.

    Parameters
    ----------
    pdf_path : Path
        Source PDF.
    max_pages : int, default 300
        Page cap (protects against runaway extraction on pathological files).
    mode : {"hybrid", "classic"}, default "hybrid"
        "hybrid" uses PyMuPDF `get_text("dict")` for structure detection
        (font-based title/body separation, column inference via block bbox),
        pdfplumber-equivalent character-accurate text within each detected
        body block, and paragraph-boundary sentinels that downstream spaCy
        segmentation respects.

        "classic" uses pdfplumber smart column extraction -- retained for A/B
        comparison and as a fallback.

        If `mode="hybrid"` but PyMuPDF is unavailable, the function
        transparently falls back to classic mode.

    Returns
    -------
    List[Tuple[int, str]]
        (page_number, text) tuples in source order.
    """
    pdf_path = Path(pdf_path)
    pages: List[Tuple[int, str]] = []

    # Hybrid extraction path (default)
    if mode == "hybrid" and HYBRID_AVAILABLE:
        pages = extract_pdf_text_hybrid(pdf_path, max_pages=max_pages)
        if pages:
            return pages
        logger.debug(
            f"Hybrid extraction returned nothing for {pdf_path.name}; "
            f"falling back to classic pipeline"
        )

    # Classic path (pdfplumber with column-aware smart extraction)
    if PDFPLUMBER_AVAILABLE:
        try:
            with pdfplumber.open(pdf_path) as pdf:
                n = min(len(pdf.pages), max_pages)
                for i in range(n):
                    try:
                        text = _extract_text_smart(pdf.pages[i])
                        if text:
                            pages.append((i + 1, text))
                    except Exception as e:
                        logger.debug(f"pdfplumber page {i+1} failed: {e}")
                        # Last-chance fallback for this page
                        try:
                            fallback = pdf.pages[i].extract_text()
                            if fallback:
                                pages.append((i + 1, _fix_hyphenation(fallback)))
                        except Exception:
                            pass
            if pages:
                return pages
        except Exception as e:
            logger.warning(f"pdfplumber failed on {pdf_path.name}: {e}")

    # Final fallback
    try:
        with open(pdf_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            n = min(len(reader.pages), max_pages)
            for i in range(n):
                try:
                    text = reader.pages[i].extract_text()
                    if text:
                        pages.append((i + 1, _fix_hyphenation(text)))
                except Exception as e:
                    logger.debug(f"PyPDF2 page {i+1} failed: {e}")
    except Exception as e:
        logger.error(f"PyPDF2 failed on {pdf_path.name}: {e}")

    return pages


# ---------------------------------------------------------------------------
# Main extraction function
# ---------------------------------------------------------------------------
def extract_sentences_from_pdf(
    pdf_path: Path,
    max_pages: int = 300,
    dedupe: bool = True,
    metadata: Optional[Dict] = None,
    metadata_extractor: Optional[Callable[[Path], Dict]] = None,
    *,
    raw: bool = False,
    segmentation_preset: Optional[Path] = None,
) -> List[ExtractedSentence]:
    """Extract all sentences from a PDF.

    Parameters
    ----------
    pdf_path : Path
        Path to PDF file.
    max_pages : int, default 300
        Stop after this many pages.
    dedupe : bool, default True
        If True, skip sentences whose hash matches an earlier one and apply
        near-duplicate filtering (bigram Jaccard >= 0.75).
    metadata : dict, optional
        Static metadata to attach to every extracted sentence (e.g.,
        {"source_id": "report_42", "domain": "annual_report"}).
    metadata_extractor : callable, optional
        Function that takes the PDF path and returns a metadata dict.
        Useful for filename-based metadata (e.g., parsing dates or IDs from
        filenames). If both `metadata` and `metadata_extractor` are given,
        the extractor's result takes precedence on key conflicts.
    raw : bool, default False
        If True, bypass the H.2 sentence reassembler entirely and return
        the spaCy/dedup output unchanged. Useful for debugging segmentation
        issues or A/B comparisons. Default behaviour (frozen #18) applies
        the reassembler to produce more complete sentences.
    segmentation_preset : Path, optional
        Path to a segmentation preset YAML (e.g. the bundled
        `klopen/templates/segmentation/turkish_regulations.yaml`). When
        given, the preset's rule list is used. When omitted (and `raw` is
        False), `LANGUAGE_AGNOSTIC_RULES` is used as a safe fallback for
        unknown-language PDFs (H.2-3 a).

    Returns
    -------
    List[ExtractedSentence]
        Sentences with metadata. Criteria filtering is NOT applied here; use
        klopen.criteria.runner next.
    """
    pdf_path = Path(pdf_path)
    filename = pdf_path.name

    # Build per-document metadata
    base_meta: Dict = {"filename": filename, "stem": pdf_path.stem}
    if metadata:
        base_meta.update(metadata)
    if metadata_extractor is not None:
        try:
            extracted = metadata_extractor(pdf_path) or {}
            base_meta.update(extracted)
        except Exception as e:
            logger.warning(f"metadata_extractor failed on {filename}: {e}")

    pages = extract_pdf_text_by_page(pdf_path, max_pages)
    logger.info(f"{filename}: extracted {len(pages)} pages")

    nlp = _get_nlp()
    sentences: List[ExtractedSentence] = []
    seen_hashes = set()
    sentence_idx = 0

    for page_num, page_text in pages:
        if not page_text:
            continue

        # Respect paragraph boundaries produced by hybrid extraction.
        # Paragraphs are separated by "\n\n" in the hybrid output; within a
        # paragraph, single newlines are wraps (safe to replace with spaces).
        # Classic extraction has no double-newlines, so this degrades
        # gracefully to the prior behavior.
        paragraphs = [p.strip() for p in page_text.split("\n\n") if p.strip()]
        if not paragraphs:
            continue

        for paragraph in paragraphs:
            # Drop heading paragraphs entirely: they carry the TITLE
            # sentinel from hybrid extraction and are not extractable units.
            if is_title_block(paragraph):
                continue

            clean = paragraph.replace("\n", " ").strip()
            if len(clean) < 10:
                continue

            # spaCy has a memory cap; chunk long paragraphs (very rare at
            # this stage but preserved for safety on pathological pages).
            chunks = [clean[i:i + 50000] for i in range(0, len(clean), 50000)]
            for chunk in chunks:
                try:
                    doc = nlp(chunk)
                    for sent in doc.sents:
                        text = sent.text.strip()
                        if len(text) < 10:
                            continue

                        h = sentence_hash(text)
                        if dedupe and h in seen_hashes:
                            continue
                        seen_hashes.add(h)

                        sentences.append(ExtractedSentence(
                            text=text,
                            hash=h,
                            page=page_num,
                            sentence_index=sentence_idx,
                            metadata=dict(base_meta),  # copy per sentence
                        ))
                        sentence_idx += 1
                except Exception as e:
                    logger.warning(
                        f"spaCy failed on {filename} p.{page_num}: {e}"
                    )

    # Second-pass dedup: near-duplicates (bigram Jaccard >= 0.75).
    # MD5 only catches character-identical duplicates; long documents
    # frequently restate the same idea with minor detail differences.
    if dedupe:
        before = len(sentences)
        sentences = _filter_near_duplicates(sentences, threshold=0.75)
        after = len(sentences)
        # Re-index to keep sentence_index contiguous after filtering.
        for new_idx, s in enumerate(sentences):
            s.sentence_index = new_idx
        logger.info(
            f"{filename}: {before} -> {after} after near-dup filter "
            f"(bigram Jaccard >= 0.75)"
        )

    # ------------------------------------------------------------------
    # Faz 3.5 Tur H.2 — Sentence reassembler integration.
    # Order: spaCy split -> hash dedup -> near-dup filter -> REASSEMBLER.
    # Reassembler is last so it sees the cleanest possible input. It
    # itself re-numerates sentence_index 0..N-1, so any prior re-index
    # is overwritten safely.
    # H.2-1 (c) raw flag bypasses entirely.
    # H.2-3 (a) language-agnostic fallback when no preset is given.
    # ------------------------------------------------------------------
    if not raw:
        # Lazy import to keep top-level import graph minimal (frozen #29 vibe)
        from klopen.extract.reassemble import (
            reassemble,
            LANGUAGE_AGNOSTIC_RULES,
        )
        if segmentation_preset is not None:
            from klopen.segmentation import (
                load_segmentation_preset,
                build_rules,
            )
            preset = load_segmentation_preset(segmentation_preset)
            rules = build_rules(preset)
            logger.info(
                f"{filename}: applying segmentation preset "
                f"{preset.name!r} ({len(rules)} rules)"
            )
        else:
            rules = LANGUAGE_AGNOSTIC_RULES
            logger.info(
                f"{filename}: applying language-agnostic reassembler "
                f"({len(rules)} rules; no preset)"
            )
        before_r = len(sentences)
        sentences = reassemble(sentences, rules=rules)
        after_r = len(sentences)
        logger.info(
            f"{filename}: reassembler {before_r} -> {after_r} sentences"
        )

    logger.info(f"{filename}: {len(sentences)} unique sentences extracted")
    return sentences


def add_context_windows(
    sentences: List[ExtractedSentence],
    window_size: int = 3,
) -> None:
    """Add `context_before` field in-place (preceding N sentences joined)."""
    for i, s in enumerate(sentences):
        start = max(0, i - window_size)
        ctx = [sentences[j].text for j in range(start, i)]
        s.context_before = " ... ".join(ctx) if ctx else ""


# ---------------------------------------------------------------------------
# CLI demo
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m klopen.extract.sentences <path_to_pdf> [n_samples]")
        sys.exit(1)

    pdf = Path(sys.argv[1])
    n_samples = int(sys.argv[2]) if len(sys.argv) > 2 else 10

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    sents = extract_sentences_from_pdf(pdf, max_pages=50)

    print(f"\n{'='*70}")
    print(f"Extracted {len(sents)} sentences from {pdf.name}")
    print(f"{'='*70}\n")

    print(f"Showing first {min(n_samples, len(sents))} sentences:\n")
    for s in sents[:n_samples]:
        print(f"[p.{s.page}] {s.text[:140]}")
        print()